window.Instascan = require('./index');
